
Description
===========
Provides number validation features for the Drupal SMS Framework. 

Installation
============

Documentation
=============
http://moo0.net/smsframework/?q=node/19

Credits
=======
aspope (http://groups.drupal.org/user/431955)
andybill (http://groups.drupal.org/user/83300)
frazras (http://groups.drupal.org/user/13934)
