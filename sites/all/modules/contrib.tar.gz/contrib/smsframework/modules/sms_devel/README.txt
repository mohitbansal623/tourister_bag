The virtual gateway part of this module is only partially working, and the
activity log (in the admin form) needs to be written. I am really struggling to
get the AJAX working to have this text field update as messages come in and out
of the virtualgw.
