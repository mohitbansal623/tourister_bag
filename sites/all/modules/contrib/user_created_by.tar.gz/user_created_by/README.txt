
*******************************************************
    README.txt for User Created By module
*******************************************************

Contents:
=========
1. ABOUT
2. REQUIREMENTS
3. USAGES
4. INSTALLATION

1. ABOUT
===========
User Created By module saves uid of user who creates other users. This is 
very helpful in sites where particular user roles are allowed to create other
users and with this module it can be easily shown who created which user.

2. REQUIREMENTS
================

* Views module.

3. USAGES
================

* In user views you can add the relationship to  User Created By: Creator Uid .
* after adding the relationship you can add as many fields you want 
  and set relationship to Creator Uid field.

3. INSTALLATION
================

* Install as usual, 
  see https://drupal.org/documentation/install/modules-themes/modules-7 for 
  further information.
