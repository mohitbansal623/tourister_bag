Commerce Reset
================


Introduction
------------

While a site is in development or testing phase we create hundreds orders, transactions and customer profiles.
This module allows you to reset commerce to a near blank slate.

At the moment we only support commerce core.



Features
--------

1. Delete orders and reset order number.

2. Delete payment transactions.

3. Delete customer profiles.

4. Delete product variations.



Basic Installation
------------------

1. Download and enable the module.

2. Go to Administration >  Store > Commerce reset (admin/commerce/reset/batch).