GA PUSH: FORM VALIDATE:
-----------------------

This submodule lets you track all validate errors for drupal forms.
You must specify the form ids to track on settings.

Configure path: /admin/config/system/ga-push/form-validate

Take attention to the googleanalytics module configuration, by default this module excludes: node/add*, node/*/*... pages you need to changes this to set information about this forms.
