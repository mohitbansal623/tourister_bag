GA Push Log
-----------

Simple example module for log exception tracking with rules on watchdog log event.
This module does not provide extra functionality.
