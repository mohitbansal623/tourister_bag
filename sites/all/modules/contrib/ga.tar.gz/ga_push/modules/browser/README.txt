GA PUSH: BROWSER
-------------------------

Send all jQuery events you set to analytics.

List of the events already set: /admin/config/system/ga-push/browser
Add new event: /admin/config/system/ga-push/browser/add